/************************************************************************************
 * Copyright (C) 2020                                                               *
 * TETCOS, Bangalore. India                                                         *
 *                                                                                  *
 * Tetcos owns the intellectual property rights in the Product and its content.     *
 * The copying, redistribution, reselling or publication of any or all of the       *
 * Product or its content without express prior written consent of Tetcos is        *
 * prohibited. Ownership and / or any other right relating to the software and all  *
 * intellectual property rights therein shall remain at all times with Tetcos.      *
 *                                                                                  *
 * Author:    Shashi Kant Suman                                                     *
 *                                                                                  *
 * ---------------------------------------------------------------------------------*/
#include "main.h"
#include "DTDMA_enum.h"
#include "DTDMA.h"
#include "NetSim_Plot.h"

int fn_NetSim_DTDMA_Mobility(NETSIM_ID nNodeId);
double codingrate_to_double_from_string(char* s);
static bool isplotinit = false;
/**
DTDMA Init function initializes the DTDMA parameters.
*/
_declspec (dllexport) int fn_NetSim_DTDMA_Init(struct stru_NetSim_Network *NETWORK_Formal,
	NetSim_EVENTDETAILS *pstruEventDetails_Formal,
	char *pszAppPath_Formal,
	char *pszWritePath_Formal,
	int nVersion_Type,
	void **fnPointer)
{
	
	if (!isplotinit)
	{
	    fn_NetSim_DTDMA_Init_Plots();
		fn_NetSim_DTDMA_init_Parameter_Log();

		isplotinit = true;
	}

	
	fn_NetSim_DTDMA_NodeInit();
	fn_NetSim_DTDMA_CalulateReceivedPower();
	init_dtdma_session();
	init_slot_formation();
	fn_NetSim_DTDMA_InitFrequencyHopping();
	fnMobilityRegisterCallBackFunction(fn_NetSim_DTDMA_Mobility);
	fnNodeJoinRegisterCallBackFunction(fnDTDMANodeJoinCallBack);
	return 0;

}

void update_receiver(NetSim_PACKET* packet)
{
	if (packet->nReceiverId)
		return; // Routing protocol will update
	if (isBroadcastPacket(packet))
		return;
	if (isMulticastPacket(packet))
		return;
	NETSIM_ID in;
	packet->nReceiverId = fn_NetSim_Stack_GetDeviceId_asIP(
		packet->pstruNetworkData->szNextHopIp, &in);
}

/**
	This function is called by NetworkStack.dll, whenever the event gets triggered		
	inside the NetworkStack.dll for the TDMA protocol									
*/
_declspec (dllexport) int fn_NetSim_DTDMA_Run()
{
	NETSIM_ID d = pstruEventDetails->nDeviceId;
	NETSIM_ID in = pstruEventDetails->nInterfaceId;

	switch(pstruEventDetails->nEventType)
	{
	case MAC_OUT_EVENT:
		{
			//Set the arrival time
			NetSim_BUFFER* buffer= DEVICE_MAC_NW_INTERFACE(pstruEventDetails->nDeviceId,pstruEventDetails->nInterfaceId)->pstruAccessBuffer;
			NetSim_PACKET* packet = fn_NetSim_Packet_GetPacketFromBuffer(buffer,0);
			if (packet)
			{
				packet->pstruMacData->dArrivalTime = pstruEventDetails->dEventTime;
				update_receiver(packet);
			}
		}
		break;
	case MAC_IN_EVENT:
		if(pstruEventDetails->pPacket->nControlDataType/100 != MAC_PROTOCOL_DTDMA)
		{
			reassemble_packet();
			if(pstruEventDetails->pPacket)
			{
				memset(pstruEventDetails->pPacket->pstruMacData,0,sizeof* pstruEventDetails->pPacket->pstruMacData);
				memset(pstruEventDetails->pPacket->pstruPhyData,0,sizeof* pstruEventDetails->pPacket->pstruPhyData);
		
				pstruEventDetails->nProtocolId = fn_NetSim_Stack_GetNWProtocol(pstruEventDetails->nDeviceId);
				pstruEventDetails->nEventType=NETWORK_IN_EVENT;
				fnpAddEvent(pstruEventDetails);
			}
		}
		else
		{
			//Free the DTDMA Frame
			fn_NetSim_Packet_FreePacket(pstruEventDetails->pPacket);
			pstruEventDetails->pPacket = NULL;
		}
		break;
	case PHYSICAL_OUT_EVENT:
		{
			fn_NetSim_DTDMA_PhysicalOut();
		}
		break;
	case PHYSICAL_IN_EVENT:
		pstruEventDetails->pPacket->pstruPhyData->nPacketErrorFlag =
		fn_NetSim_DTDMA_CalculatePacketError(d, in, pstruEventDetails->pPacket);

		//Function calls
		double dThemalNoise= 0; //in dBm
		double dBandwidth;
		
		double dRx_Power = GET_RX_POWER_dbm(pstruEventDetails->nDeviceId, pstruEventDetails->nInterfaceId,d, in);
		DTDMA_NODE_PHY* phy = DTDMA_PHY(pstruEventDetails->pPacket->nTransmitterId, in);
		PPROPAGATION_INFO**** info = propagationHandle;
		PPROPAGATION_INFO pinfo = info[pstruEventDetails->pPacket->nTransmitterId][in][pstruEventDetails->nDeviceId][pstruEventDetails->nInterfaceId];
		double fading = propagation_calculate_fadingloss(propagationHandle,pstruEventDetails->pPacket->nTransmitterId,in,pstruEventDetails->nDeviceId, pstruEventDetails->nInterfaceId);
		double ber= calculate_BER(phy->modulation,GET_RX_POWER_dbm(pstruEventDetails->pPacket->nTransmitterId, pstruEventDetails->nInterfaceId,d, in),
			phy->dBandwidth);
		double snr= dRx_Power - dThemalNoise;

		
		fn_NetSim_DTDMA_Log_Parameters(pinfo, fading, snr, ber);
		fn_NetSim_DTDMA_add_PropagationInfo_Plot_data(pinfo, fading, snr, ber);
		fn_NetSim_DTDMA_add_Power_Plot_data(pinfo, snr, ber);

		
		pstruEventDetails->pPacket->nPacketStatus = pstruEventDetails->pPacket->pstruPhyData->nPacketErrorFlag;
		fn_NetSim_Metrics_Add(pstruEventDetails->pPacket);
		fn_NetSim_WritePacketTrace(pstruEventDetails->pPacket);
		if(pstruEventDetails->pPacket->nPacketStatus == PacketStatus_NoError)
		{
			pstruEventDetails->nEventType=MAC_IN_EVENT;
			fnpAddEvent(pstruEventDetails);
		}
		else
		{
			fn_NetSim_Packet_FreePacket(pstruEventDetails->pPacket);
		}
		break;
	case TIMER_EVENT:
		{
			switch(pstruEventDetails->nSubEventType)
			{
			case DTDMA_SCHEDULE_Transmission:
				fn_NetSim_DTDMA_FrequencyHopping();
				fn_NetSim_DTDMA_SendToPhy();
				break;
			case DTDMA_FORM_SLOT:
				fn_NetSim_DTDMA_FormSlot();
				break;
			default:
				fnNetSimError("Unknown subevent %d for Timer event in DTDMA protocol\n",pstruEventDetails->nSubEventType);
				break;
			}
		}
		break;
	default:
		fnNetSimError("Unknown event %d for DTDMA Mac protocol",pstruEventDetails->nEventType);
		break;
	}
	return 0;
}

/**
	This function is called by NetworkStack.dll, once simulation end to free the 
	allocated memory for the network.	
*/
_declspec(dllexport) int fn_NetSim_DTDMA_Finish()
{
	NETSIM_ID i, j;
	for (i = 0; i < NETWORK->nDeviceCount; i++)
	{
		for (j = 0; j < DEVICE(i + 1)->nNumOfInterface; j++)
		{
			if (!isDTDMAConfigured(i + 1, j + 1))
				continue;

			if (NETWORK->ppstruDeviceList[i]->ppstruInterfaceList[j]->pstruMACLayer->nMacProtocolId == MAC_PROTOCOL_DTDMA)
			{
				DTDMA_NODE_MAC* mac = DTDMA_MAC(i + 1, j + 1);
				DTDMA_NODE_PHY* phy = DTDMA_PHY(i + 1, j + 1);
				free(mac);
				free(phy);
			}


		}
	}
	propagation_finish(propagationHandle);
	fn_NetSim_DTDMA_FinishFrequencyHopping();
	free_dtdma_session();
	return 0;
}

/**
	This function is called by NetworkStack.dll, while writing the event trace 
	to get the sub event as a string.
*/
_declspec (dllexport) char* fn_NetSim_DTDMA_Trace(int nSubEvent)
{
	return GetStringDTDMA_Subevent(nSubEvent);
}

/**
	This function is called by NetworkStack.dll, while configuring the device 
	for DTDMA protocol.	
*/
_declspec(dllexport) int fn_NetSim_DTDMA_Configure(void** var)
{
	char* tag;
	void* xmlNetSimNode;
	NETSIM_ID nDeviceId;
	NETSIM_ID nInterfaceId;
	LAYER_TYPE nLayerType;
	char* szVal;

	tag = (char*)var[0];
	xmlNetSimNode=var[2];
	if(!strcmp(tag,"PROTOCOL_PROPERTY"))
	{
		NETWORK=(struct stru_NetSim_Network*)var[1];
		nDeviceId = *((NETSIM_ID*)var[3]);
		nInterfaceId = *((NETSIM_ID*)var[4]);
		nLayerType = *((LAYER_TYPE*)var[5]);
		switch(nLayerType)
		{
		case MAC_LAYER:
			{
				DTDMA_NODE_MAC* nodeMac=DTDMA_MAC(nDeviceId,nInterfaceId);
				if(!nodeMac)
				{
					nodeMac=(DTDMA_NODE_MAC*)calloc(1,sizeof* nodeMac);
					DEVICE_MACVAR(nDeviceId,nInterfaceId)=nodeMac;
				}
				//Get the MAC address
				szVal = fn_NetSim_xmlConfig_GetVal(xmlNetSimNode,"MAC_ADDRESS",1);
				if(szVal)
				{
					NETWORK->ppstruDeviceList[nDeviceId-1]->ppstruInterfaceList[nInterfaceId-1]->pstruMACLayer->szMacAddress = STR_TO_MAC(szVal);
					fnpFreeMemory(szVal);
				}

				getXmlVar(&szVal,NETWORK_TYPE,xmlNetSimNode,1,_STRING,DTDMA);
				if(!_stricmp(szVal,"AD-HOC"))
					nodeMac->network_type=ADHOC;
				else
					nodeMac->network_type=INFRASTRUCTURE;
				free(szVal);

				getXmlVar(&szVal,SLOT_ALLOCATION_TECHNIQUE,xmlNetSimNode,1,_STRING,DTDMA);
				if (!_stricmp(szVal, "ROUNDROBIN"))
					nodeMac->slot_allocation_technique = TECHNIQUE_ROUNDROBIN;
				else if (!_stricmp(szVal, "DEMAND_BASED"))
					nodeMac->slot_allocation_technique = TECHNIQUE_DEMANDBASED;
				else if (!_stricmp(szVal, "FILEBASED"))
					nodeMac->slot_allocation_technique = TECHNIQUE_FILE;
				free(szVal);
				if(nodeMac->slot_allocation_technique==TECHNIQUE_DEMANDBASED)
				{
					getXmlVar(&nodeMac->max_slot,MAX_SLOT_PER_DEVICE,xmlNetSimNode,1,_INT,DTDMA);
					getXmlVar(&nodeMac->min_slot,MIN_SLOT_PER_DEVICE,xmlNetSimNode,1,_INT,DTDMA);
				}

				//Get the SLOT_DURATION
				getXmlVar(&nodeMac->dSlotDuration,SLOT_DURATION,xmlNetSimNode,1,_DOUBLE,DTDMA);
				nodeMac->dSlotDuration*=MILLISECOND;
				//Get the FRAME_DURATION
				getXmlVar(&nodeMac->dFrameDuration,FRAME_DURATION,xmlNetSimNode,1,_DOUBLE,DTDMA);
				nodeMac->dFrameDuration *= SECOND;
				//Get the NET_COUNT
				getXmlVar(&nodeMac->nNetCount,NET_COUNT,xmlNetSimNode,1,_INT,DTDMA);
				//Get the NET_ID
				getXmlVar(&nodeMac->nNetId,NET_ID,xmlNetSimNode,1,_INT,DTDMA);
				//Get the guard interval
				getXmlVar(&nodeMac->dGuardInterval,GUARD_INTERVAL,xmlNetSimNode,1,_DOUBLE,DTDMA);
			}
			break;
		case PHYSICAL_LAYER:
			{
				DTDMA_NODE_PHY* phy=DTDMA_PHY(nDeviceId,nInterfaceId);
				if(!phy)
				{
					phy=(DTDMA_NODE_PHY*)calloc(1,sizeof* phy);
					DEVICE_PHYVAR(nDeviceId,nInterfaceId)=phy;
				}
				//Get the LOWER_FREQUENCY
				getXmlVar(&phy->dLowerFrequency,LOWER_FREQUENCY,xmlNetSimNode,1,_DOUBLE,DTDMA);
				//Get the UPPER_FREQUENCY
				getXmlVar(&phy->dUpperFrequency,UPPER_FREQUENCY,xmlNetSimNode,1,_DOUBLE,DTDMA);
				//Get the BANDWIDTH
				getXmlVar(&phy->dBandwidth,BANDWIDTH,xmlNetSimNode,1,_DOUBLE,DTDMA);
				phy->dBandwidth /= 1000;
				//Get the FREQUENCY_HOPPING
				getXmlVar(&szVal,FREQUENCY_HOPPING,xmlNetSimNode,1,_STRING,DTDMA);
				if(!_stricmp(szVal,"ON"))
					phy->frequency_hopping=true;
				else
					phy->frequency_hopping=false;
				//Get the TX_POWER
				getXmlVar(&phy->dTXPower,TX_POWER,xmlNetSimNode,1,_DOUBLE,DTDMA);
				phy->dTXPower *= 1000;
				//Get the RECEIVER_SENSITIVITY_DBM
				getXmlVar(&phy->dReceiverSensitivity,RECEIVER_SENSITIVITY_DBM,xmlNetSimNode,1,_DOUBLE,DTDMA);
				//Get the modulation
				getXmlVar(&szVal,MODULATION_TECHNIQUE,xmlNetSimNode,1,_STRING,DTDMA);
				phy->modulation = getModulationFromString(szVal);
				free(szVal);
				getXmlVar(&szVal, CODING_RATE, xmlNetSimNode, 1, _STRING, DTDMA);
				phy->codingRate = codingrate_to_double_from_string(szVal);
				free(szVal);

				getXmlVar(&phy->symbolRate, DATA_SYMBOL_RATE_KBD, xmlNetSimNode, 1, _UINT, DTDMA);
				phy->symbolRate *= 1000;

				getXmlVar(&phy->dAntennaHeight, ANTENNA_HEIGHT, xmlNetSimNode, 1, _DOUBLE, DTDMA);
				getXmlVar(&phy->dAntennaGain, ANTENNA_GAIN, xmlNetSimNode, 1, _DOUBLE, DTDMA);
				getXmlVar(&phy->d0, D0, xmlNetSimNode, 1, _DOUBLE, DTDMA);
				getXmlVar(&phy->pld0, PL_D0, xmlNetSimNode, 0, _DOUBLE, DTDMA);

				getXmlVar(&phy->isFEC, FEC_CODING, xmlNetSimNode, 1, _BOOL, DTDMA);

			}
			break;
		default:
			NetSimxmlError("Unknown layer type for D-TDMA protocol","",xmlNetSimNode);
			break;
		}
	}
	return 0;
}

/**
	This function is called by NetworkStack.dll, to free the TDMA protocol data.
*/
_declspec(dllexport) int fn_NetSim_DTDMA_FreePacket(NetSim_PACKET* pstruPacket)
{
	if(pstruPacket->pstruMacData->Packet_MACProtocol)
	{
		PDTDMA_MAC_PACKET mp = (PDTDMA_MAC_PACKET)pstruPacket->pstruMacData->Packet_MACProtocol;
		free(mp);
	}
	pstruPacket->pstruMacData->Packet_MACProtocol=NULL;
	return 0;
}

/**
	This function is called by NetworkStack.dll, to copy the TDMA protocol
	details from source packet to destination.
*/
_declspec(dllexport) int fn_NetSim_DTDMA_CopyPacket(NetSim_PACKET* pstruDestPacket,NetSim_PACKET* pstruSrcPacket)
{
	if(pstruSrcPacket->pstruMacData->Packet_MACProtocol)
	{
		PDTDMA_MAC_PACKET mp = (PDTDMA_MAC_PACKET)pstruSrcPacket->pstruMacData->Packet_MACProtocol;
		pstruDestPacket->pstruMacData->Packet_MACProtocol = calloc(1,sizeof* mp);
		memcpy(pstruDestPacket->pstruMacData->Packet_MACProtocol,mp,sizeof* mp);
	}
	return 0;
}

/**
This function write the Metrics 	
*/
_declspec(dllexport) int fn_NetSim_DTDMA_Metrics(PMETRICSWRITER metricsWriter)
{
	return 0;
}

/**
This function will return the string to write packet trace heading.
*/
_declspec(dllexport) char* fn_NetSim_DTDMA_ConfigPacketTrace()
{
	return "";
}

/**
 This function will return the string to write packet trace.																									
*/
_declspec(dllexport) char* fn_NetSim_DTDMA_WritePacketTrace(NetSim_PACKET* pstruPacket, char** ppszTrace)
{
	return "";
}

int fn_NetSim_DTDMA_Mobility(NETSIM_ID nNodeId)
{
	NETSIM_ID t, ti, i;
	for (i = 0; i < DEVICE(nNodeId)->nNumOfInterface; i++)
	{
		if (!isDTDMAConfigured(nNodeId, i + 1))
			continue;

		for (t = 0; t < NETWORK->nDeviceCount; t++)
		{
			if (nNodeId == t + 1)
				continue;

			for (ti = 0; ti < DEVICE(t + 1)->nNumOfInterface; ti++)
			{
				if (!isDTDMAConfigured(t + 1, ti + 1))
					continue;

				dtdma_CalculateReceivedPower(t + 1, ti + 1, nNodeId, i + 1);
				dtdma_CalculateReceivedPower(nNodeId, i + 1, t + 1, ti + 1);

				
			}
		}
	}
	return 0;
}

PHY_MODULATION getModulationFromString(char* val)
{
	if(!_stricmp(val,"QPSK"))
		return Modulation_QPSK;
	else if(!_stricmp(val,"BPSK"))
		return Modulation_BPSK;
	else if(!_stricmp(val,"16QAM"))
		return Modulation_16_QAM;
	else if(!_stricmp(val,"64QAM"))
		return Modulation_64_QAM;
	else if (!_stricmp(val, "GMSK"))
		return Modulation_GMSK;
	else
	{
		fnNetSimError("Unknown modulation %s for D-TDMA protocol. Assigning QPSK\n",val);
		return Modulation_QPSK;
	}
}

double codingrate_to_double_from_string(char* s)
{
	char* u = strtok(s, "/");
	char* d = strtok(NULL, "\0");
	return atof(u) / atof(d);
}

int fnDTDMANodeJoinCallBack(NETSIM_ID nDeviceId, double time, NODE_ACTION action)
{
	NETSIM_ID i;
	for (i = 0; i < DEVICE(nDeviceId)->nNumOfInterface; i++)
	{
		if (!isDTDMAConfigured(nDeviceId, i + 1))
			continue;
		PDTDMA_NODE_MAC mac = DTDMA_MAC(nDeviceId, i + 1);
		if (action == JOIN)
			mac->nodeInfo->nodeAction = CONNECTED;
		else if (action == LEAVE)
			mac->nodeInfo->nodeAction = NOT_CONNECTED;
		else
			fnNetSimError("Unknown action %d in function fnDTDMANodeJoinCallBack\n", action);
	}
	return 0;
}

static UINT get_modulation_bit(PHY_MODULATION m)
{
	switch (m)
	{
		case Modulation_GMSK: return 1;
		case Modulation_BPSK: return 1;
		case Modulation_QPSK: return 2;
		case Modulation_16_QAM: return 4;
		case Modulation_64_QAM: return 6;
		default:
			return 2;
	}
}

int fn_NetSim_DTDMA_NodeInit()
{

	NETSIM_ID i, j;
	for (i = 0; i < NETWORK->nDeviceCount; i++)
	{
		for (j = 0; j < DEVICE(i + 1)->nNumOfInterface; j++)
		{

			if (!isDTDMAConfigured(i + 1, j + 1))
				continue;
			
			NetSim_BUFFER* buffer = DEVICE_ACCESSBUFFER(i + 1, j + 1);
			DTDMA_NODE_MAC* mac = DTDMA_MAC(i + 1, j + 1);
			DTDMA_NODE_PHY* phy = DTDMA_PHY(i + 1, j + 1);
			mac->nSlotCountInFrame = (unsigned int)(mac->dFrameDuration / (mac->dSlotDuration + mac->dGuardInterval));
			mac->nFrameCount = (unsigned int)ceil(NETWORK->pstruSimulationParameter->dVal / (mac->dFrameDuration + DTDMA_INTER_FRAME_GAP));
			phy->symbolPerSlot = (UINT)((mac->dSlotDuration/SECOND) * phy->symbolRate);
			mac->bitsPerSlot = (UINT)(phy->symbolPerSlot * get_modulation_bit(phy->modulation) * phy->codingRate);
			phy->dDataRate = mac->bitsPerSlot / mac->dSlotDuration;

			mac->reassembly = (NetSim_PACKET**)calloc(NETWORK->nDeviceCount, sizeof* mac->reassembly);
			
			if (buffer->nSchedulingType == SCHEDULING_NONE)
				buffer->nSchedulingType = SCHEDULING_FIFO;
		}
	}
	return 0;
}

char* log_parameter_list[] = { "TOTALLOSS","PATHLOSS","SHADOWLOSS","FADINGLOSS","SNR","RX_POWER","BER"};
char* logfilename = "DTDMA_Parameter_Log.csv";

int fn_NetSim_DTDMA_init_Parameter_Log()
{
	char* temp;
	char input[BUFSIZ], logfile[BUFSIZ];
	UINT line = 0;
	FILE* fp, * fp1;
	char data[BUFSIZ];
	char* parameter;
	char* filename = "USER_INPUT_DTDMA_PLOTS.txt";
	sprintf(input, "%s%s%s", pszIOLogPath, pathSeperator, filename);
	sprintf(logfile, "%s%s%s", pszIOLogPath, pathSeperator, logfilename);

	if (!parameter_log_info)
		parameter_log_info = calloc(1, sizeof * parameter_log_info);

	ptrINFO info = parameter_log_info;
	info->isParameterlog = false;
	info->totalloss = false;
	info->pathloss = false;
	info->shadowloss = false;
	info->fadingloss = false;
	info->dReceivedPower = false;
	info->dber = false;
	info->dsnr = false;

	//Prarmeter list


	fp1 = fopen(logfile, "w+");
	if (fp1 == NULL )
	{
		info->isParameterlog = false;
		perror(logfile);
		fnNetSimError("Unable to open %s file %s", filename, input);
		return 0;
	}
	else
	{
		info->isParameterlog = true;
		fprintf(fp1, "Time(MicroSeconds),Tx_DeviceName,Rx_DeviceName,Distance,");

		int param_size = sizeof(log_parameter_list) / sizeof(char*);
		bool valid_param = false;
		for (int i = 0; i < param_size; i++)
		{
			fp = fopen(input, "r");
			if (fp1 == NULL || fp == NULL)
			{
				info->isParameterlog = false;
				perror(input);
				fnNetSimError("Unable to open %s file %s", filename, input);
				return 0;
			}
			while (fgets(data, BUFSIZ, fp))
			{
				temp = data;
				line++;
				lskip(temp);
				if (*temp == '\n')
					continue;
				if (*temp == '#' || *temp == 0)
					continue;

				char* newline = strchr(temp, '\n'); if (newline) *newline = 0;
				char* token = strtok(temp, ",");
				parameter = token;
				if (!strcmp(strupr(token), log_parameter_list[i]))
				{
					valid_param = true;
					switch (i)
					{
					case 0:
						if (!info->totalloss)
						{
							info->totalloss = true;
							fprintf(fp1, "TotalLoss(dB),");
						}
						break;
					case 1:
						if (!info->pathloss)
						{
							info->pathloss = true;
							fprintf(fp1, "PathLoss(dB),");
						}
						break;
					case 2:
						if (!info->shadowloss)
						{
							info->shadowloss = true;
							fprintf(fp1, "ShadowLoss(dB),");
						}
						break;
					case 3:

						if (!info->fadingloss)
						{
							info->fadingloss = true;
							fprintf(fp1, "FadingLoss(dB),");
						}
						break;

					case 4:
						if (!info->dReceivedPower)
						{
							info->dReceivedPower = true;
							fprintf(fp1, "ReceivedPower(dBm),");
						}
						break;
					case 5:
						{
							info->dber = true;
							fprintf(fp1, "BER,");

						}
						break;
					case 6:
					{
						info->dsnr = true;
						fprintf(fp1, "SNR(dB),");
					}
					default:
						break;
					}
					break;
				}

				if (!valid_param)
				{
					fprintf(stderr, "Invalid Input: \"%s\" detected in line %d.\nPlease edit the file and re-run simulation.\n"
						"Press any key to skip this line and continue simulation.\n", token, line);
					_getch();
				}
			}
			fclose(fp);


		}

		fclose(fp1);
	}

	return 1;
}

int fn_NetSim_DTDMA_Log_Parameters(PPROPAGATION_INFO pinfo, double fadingloss, double snr,double ber)
{
	FILE* fp;
	char logfile[BUFSIZ];

	sprintf(logfile, "%s%s%s", pszIOLogPath, pathSeperator, logfilename);
	fp = fopen(logfile, "a+");
	if (fp)
	{
		ptrINFO param_info = parameter_log_info;
		fprintf(fp, "\n%lf,%s,%s,%lf,", pstruEventDetails->dEventTime,
			DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId),
			DEVICE_DISTANCE(pinfo->nTxId, pinfo->nRxId));

		double TotalLoss = pinfo->recvPower->dPathloss_db+pinfo->recvPower->dShadowLoss_db + fadingloss;

		//TOTALLOSS
		if (param_info->totalloss)
		{
			fprintf(fp, "%lf,", -(TotalLoss));

		}

		//PATHLOSS
		if (param_info->pathloss)
		{
			fprintf(fp, "%lf,", -(pinfo->recvPower->dPathloss_db));

		}
		//SHADOWLOSS
		if (param_info->shadowloss)
		{
			fprintf(fp, "%lf,", pinfo->recvPower->dShadowLoss_db);
		}

		//FADINGLOSS
		if (param_info->fadingloss)
		{

			fprintf(fp, "%lf,", fadingloss);

		}

		//RX_POWER
		if (param_info->dReceivedPower)
		{
			fprintf(fp, "%lf,", pinfo->recvPower->dRxPower_dbm);
		}

		//BER

		if (param_info->dber)
		{
			fprintf(fp, "%lf,", ber);
	    }

		//SNR

		if (param_info->dsnr)
		{
			fprintf(fp, "%lf,",snr);
		}

		fclose(fp);
	}
	else
		return 0;

	return 1;
}

char*parameter_list[] = { "TOTALLOSS","PATHLOSS","SHADOWLOSS","FADINGLOSS","SNR","RX_POWER","BER"};

int fn_NetSim_DTDMA_Init_Plots()
{
	char input[BUFSIZ];
	FILE* fp;
	char* filename = "USER_INPUT_DTDMA_PLOTS.txt";
	sprintf(input, "%s%s%s", pszIOLogPath, pathSeperator, filename);
	char* temp;
	UINT line = 0;
	char data[BUFSIZ];
	char* parameter;
	char command[BUFSIZ];
	int devid1 = 0, devid2 = 0;

	sprintf(input, "%s%s%s", pszIOLogPath, pathSeperator, filename);

	if ((fp = fopen(input, "r")))
	{
		fclose(fp);
		fprintf(stderr, "\nFile \"%s\" found in \"%s\"\n", filename, pszIOLogPath);
		fprintf(stderr, "\nPlease update, save and close the file and Press any key to continue..\n");
		sprintf(command, "notepad %s", input);
		system(command);
		_getch();
	}
	else
	{
		FILE* fp = fopen(input, "w+");
		if (fp)
		{
			fprintf(stderr, "\nFile \"%s\" not found in \"%s\"\n", filename, pszIOLogPath);
			fprintf(fp, "%s\n", "# This file can be used to configure the DTDMA plot generation for each simulation run\n"
				"# You can configure the WirelessNodes for which you wish to plot various parameters over time\n"
				"# The parameter set includes Totalloss, Pathloss, ShadowLoss ,FadingLoss, RX Power\n"
				"# All loss parameters require Tx and Rx\n"
				"# Sample format below (,) is the separator\n"
				"# TOTALLOSS,<TX_device_name1>,<RX_device_name1>\n"
				"# PATHLOSS,<TX_device_name1>,<RX_device_name1>\n"
				"# SHADOWLOSS,<TX_device_name1>,<RX_device_name1>\n"
				"# FADINGLOSS,<TX_device_name1>,<RX_device_name1>\n"
				"# SNR,<TX_device_name2>,<RX_device_name2>\n"
				"# RX_POWER,<TX_device_name2>,<RX_device_name2>\n"
				"# BER,<TX_device_name2>,<RX_device_name2>\n"
				"# Any line starting with # will be treated as comment line and ignored during processing.\n"
				"# Any empty or blank line will also be ignored.\n");

			fclose(fp);
			fprintf(stderr, "\nA \"%s\" file has been written to the Path: %s", filename, pszIOLogPath);
			fprintf(stderr, "\nPlease update, save and close the file and Press any key to continue..\n");
			sprintf(command, "notepad %s", input);
			system(command);
			_getch();
		}
		else
		{
			fprintf(stderr, "\nAttempt to write \"%s\" file in Path: \"%s\" failed\n"
				"Press any key to continue simulation without input file\n", filename, pszIOLogPath);
			_getch();
		}

	}

	fp = fopen(input, "r");
	if (fp == NULL)
	{
		perror(input);
		fnNetSimError("Unable to open %s file %s", filename, input);
	}
	else
	{
		while (fgets(data, BUFSIZ, fp))
		{
			temp = data;
			line++;
			lskip(temp);
			if (*temp == '\n')
				continue;
			if (*temp == '#' || *temp == 0)
				continue;

			char* newline = strchr(temp, '\n'); if (newline) *newline = 0;
			char* token = strtok(temp, ",");
			parameter = token;
			int param_size = sizeof(parameter_list) / sizeof(char*);
			bool valid_param = false;
			for (int i = 0; i < param_size; i++)
			{
				if (!strcmp(strupr(token), parameter_list[i]))
				{
					valid_param = true;
					break;
				}
			}

			if (!valid_param)
			{
				fprintf(stderr, "Invalid Input: \"%s\" detected in line %d.\nPlease edit the file and re-run simulation.\n"
					"Press any key to skip this line and continue simulation.\n", token, line);
				_getch();
			}
			else
			{
				if (token != NULL)
					token = strtok(NULL, ",");
				devid1 = fn_NetSim_Stack_GetDeviceId_asName(token);
				if (!devid1)
				{
					fprintf(stderr, "Invalid Input detected in line %d.\n\"%s\" is not a valid Device Name. Please edit the file and re-run simulation. \n"
						"Press any key to skip this line and continue simulation.\n", line, token);
					_getch();
				}
				else
				{
					bool dev1 = false;
					for (NETSIM_ID in = 1; in <= DEVICE(devid1)->nNumOfInterface; in++)
					{
						
						if (isDTDMAConfigured(devid1, in))
						{
							dev1 = true;
							break;
						}
					}
					if (!dev1)
					{
						fprintf(stderr, "Invalid Input detected in line %d.\n\"%s\" is not a valid DTDMA Device. Please edit the file and re-run simulation. \n"
							"Press any key to skip this line and continue simulation.\n", line, token);
						_getch();
					}
					else
					{
						if (token == NULL)
							continue;
						else
						{
							token = strtok(NULL, ",");
							devid2 = fn_NetSim_Stack_GetDeviceId_asName(token);
							if (!devid2)
							{
								fprintf(stderr, "Invalid Input detected in line %d.\n\"%s\" is not a valid Device Name. Please edit the file and re-run simulation. \n"
									"Press any key to skip this line and continue simulation.\n", line, token);
								_getch();
							}
							else
							{
								bool dev2 = false;
								for (NETSIM_ID in = 1; in <= DEVICE(devid2)->nNumOfInterface; in++)
								{
									
									if (isDTDMAConfigured(devid2, in) || isDTDMAConfigured(devid2, in))
									{
										dev2 = true;
										break;
									}
								}
								if (!dev2)
								{
									fprintf(stderr, "Invalid Input detected in line %d.\n\"%s\" is not a valid DTDMA Device. Please edit the file and re-run simulation. \n"
										"Press any key to skip this line and continue simulation.\n", line, token);
									_getch();
								}
								else
									continue;
							}
						}
					}
				}
			}
			continue;
		}
		fclose(fp);
		
	}
}

int fn_NetSim_DTDMA_init_PropagationInfo_Plots(PPROPAGATION_INFO pinfo)
{
	ptrplotINFO**** info = parameter_plot_info;
	ptrplotINFO info1 = info[pinfo->nTxId][pinfo->nTxInterface][pinfo->nRxId][pinfo->nRxInterface];

	//TOTALLOSS
	if (fn_NetSim_DTDMA_Set_Plot_Flag("TOTALLOSS", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId)) ||
		fn_NetSim_DTDMA_Set_Plot_Flag("TOTALLOSS", DEVICE_NAME(pinfo->nRxId), DEVICE_NAME(pinfo->nTxId)))
		info1->isTotalLossPlotEnable = true;

	else
		info1->isTotalLossPlotEnable = false;

	if (info1->isTotalLossPlotEnable && info1->netsimTotalLossPlotVar == NULL)
		info1->netsimTotalLossPlotVar = fn_NetSim_DTDMA_init_TotalLoss_Plot(pinfo);

	//PATHLOSS
	if (fn_NetSim_DTDMA_Set_Plot_Flag("PATHLOSS", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId)) ||
		fn_NetSim_DTDMA_Set_Plot_Flag("PATHLOSS", DEVICE_NAME(pinfo->nRxId), DEVICE_NAME(pinfo->nTxId)))

		info1->isPathLossPlotEnable = true;
	else
		info1->isPathLossPlotEnable = false;

	if (info1->isPathLossPlotEnable && info1->netsimPathLossPlotVar == NULL)
		info1->netsimPathLossPlotVar = fn_NetSim_DTDMA_init_Pathloss_Plot(pinfo);

	//SHADOWLOSS

	if (fn_NetSim_DTDMA_Set_Plot_Flag("SHADOWLOSS", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId)) ||
		fn_NetSim_DTDMA_Set_Plot_Flag("SHADOWLOSS", DEVICE_NAME(pinfo->nRxId), DEVICE_NAME(pinfo->nTxId)))

		info1->isShadowLossPlotEnable = true;
	else
		info1->isShadowLossPlotEnable = false;

	if (info1->isShadowLossPlotEnable && info1->netsimShadowLossPlotVar == NULL)
		info1->netsimShadowLossPlotVar = fn_NetSim_DTDMA_init_Shadowloss_Plot(pinfo);

	//FADINGLOSS

	if (fn_NetSim_DTDMA_Set_Plot_Flag("FADINGLOSS", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId)) ||
		fn_NetSim_DTDMA_Set_Plot_Flag("FADINGLOSS", DEVICE_NAME(pinfo->nRxId), DEVICE_NAME(pinfo->nTxId)))

		info1->isFadingLossPlotEnable = true;
	else
		info1->isFadingLossPlotEnable = false;

	if (info1->isFadingLossPlotEnable && info1->netsimFadingLossPlotVar == NULL)
		info1->netsimFadingLossPlotVar = fn_NetSim_DTDMA_init_FadingLoss_Plot(pinfo);

}

//TOTALLOSS

void* fn_NetSim_DTDMA_init_TotalLoss_Plot(PPROPAGATION_INFO pinfo)
{
	char heading[BUFSIZ];
	sprintf(heading, "TotalLoss_%s_IF%d_%s_IF%d",
		//Two aruuguments device interface
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));
	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"TotalLoss_vs_Time", heading, "TotalLoss (dB)", 1, heading);

}
//PATHLOSS
void* fn_NetSim_DTDMA_init_Pathloss_Plot(PPROPAGATION_INFO pinfo)
{
	char heading[BUFSIZ];
	sprintf(heading, "PathLoss_%s_IF%d_%s_IF%d",
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));
	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"PathLoss_vs_Time", heading, "PathLoss (dB)", 1, heading);
}
//SHADOWLOSS
void* fn_NetSim_DTDMA_init_Shadowloss_Plot(PPROPAGATION_INFO pinfo)
{
	char heading[BUFSIZ];
	sprintf(heading, "ShadowLoss_%s_IF%d_%s_IF%d",
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));
	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"ShadowLoss_vs_Time", heading, "ShadowLoss (dB)", 1, heading);
}

//FADINGLOSS
void* fn_NetSim_DTDMA_init_FadingLoss_Plot(PPROPAGATION_INFO pinfo)
{
	char heading[BUFSIZ];
	sprintf(heading, "FadingLoss_%s_IF%d_%s_IF%d",
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));
	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"FadingLoss_vs_Time", heading, "FadingLoss (dB)", 1, heading);

}

//RX_Power
void* fn_NetSim_DTDMA_init_Rx_Power_Plot(PPROPAGATION_INFO pinfo)
{
	char plotheading[BUFSIZ];
	sprintf(plotheading, "Rx_Power_%s_IF%d_%s_IF%d",
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));

	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"Rx_Power_vs_Time", plotheading, "Rx_Power (dBm)", 1, plotheading);
}

//BER

void* fn_NetSim_DTDMA_init_BER_Plot(PPROPAGATION_INFO pinfo)
{
	char plotheading[BUFSIZ];
	sprintf(plotheading, "BER_%s_IF%d_%s_IF%d",
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));

	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"BER_vs_Time", plotheading, "BER", 1, plotheading);

}

//SNR

void* fn_NetSim_DTDMA_init_SNR_Plot(PPROPAGATION_INFO pinfo)
{
	char plotheading[BUFSIZ];
	sprintf(plotheading, "SNR_%s_IF%d_%s_IF%d",
		DEVICE_NAME(pinfo->nTxId), DEVICE_INTERFACE_CONFIGID(pinfo->nTxId, pinfo->nTxInterface),
		DEVICE_NAME(pinfo->nRxId), DEVICE_INTERFACE_CONFIGID(pinfo->nRxId, pinfo->nRxInterface));

	return fn_NetSim_Install_Metrics_Plot(Plot_Custom,
		"SNR_vs_Time", plotheading, "SNR (dB)", 1, plotheading);
}


int fn_NetSim_DTDMA_init_Power_Plots(PPROPAGATION_INFO pinfo)
{
	ptrplotINFO**** info = parameter_plot_info;
	ptrplotINFO info1 = info[pinfo->nTxId][pinfo->nTxInterface][pinfo->nRxId][pinfo->nRxInterface];
	
	//RX_POWER
	info1->isrxPowerPlotEnable = fn_NetSim_DTDMA_Set_Plot_Flag("RX_POWER", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId));
	if (info1->isrxPowerPlotEnable && info1->netsimrxPowerPlotVar == NULL)
		info1->netsimrxPowerPlotVar = fn_NetSim_DTDMA_init_Rx_Power_Plot(pinfo);

	//BER
	info1->isBERPlotEnable = fn_NetSim_DTDMA_Set_Plot_Flag("BER", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId));
	if (info1->isBERPlotEnable && info1->netsimBERPlotVar == NULL)
		info1->netsimBERPlotVar = fn_NetSim_DTDMA_init_BER_Plot(pinfo);

	//SNR
	info1->isSNRPlotEnable = fn_NetSim_DTDMA_Set_Plot_Flag("SNR", DEVICE_NAME(pinfo->nTxId), DEVICE_NAME(pinfo->nRxId));
	if (info1->isSNRPlotEnable && info1->netsimSNRPlotVar == NULL)
		info1->netsimSNRPlotVar = fn_NetSim_DTDMA_init_SNR_Plot(pinfo);



}


bool fn_NetSim_DTDMA_Set_Plot_Flag(char* parameter, char* device1, char* device2)
{
	char* temp;
	char input[BUFSIZ];
	UINT line = 0;
	FILE* fp;
	char data[BUFSIZ];
	char* filename = "USER_INPUT_DTDMA_PLOTS.txt";
	bool status = false;
	sprintf(input, "%s%s%s", pszIOLogPath, pathSeperator, filename);

	fp = fopen(input, "r");
	if (fp == NULL)
	{
		perror(input);
		fnNetSimError("Unable to open %s file %s", filename, input);
		status = false;
	}
	while (fgets(data, BUFSIZ, fp))
	{
		temp = data;
		line++;
		lskip(temp);
		if (*temp == '\n')
			continue;
		if (*temp == '#' || *temp == 0)
			continue;
		char delimit[] = ",";
		char* newline = strchr(temp, '\n'); if (newline) *newline = 0;
		char* token = strtok(temp, delimit);

		if (!strcmp(parameter, strupr(token)))
		{
			if (token != NULL)
				token = strtok(NULL, ",");
			if (!fn_NetSim_Stack_GetDeviceId_asName(token))
				status = false;
			else if (strcmp(device1, strupr(token)))
				status = false;
			else
			{
				if (token == NULL)
					status = false;
				else
				{
					token = strtok(NULL, ",");
					if (!fn_NetSim_Stack_GetDeviceId_asName(token))
						status = false;
					else if (strcmp(device2, strupr(token)))
						status = false;
					else
					{
						status = true;
						break;
					}
				}
			}
		}
		else
			continue;
	}
	fclose(fp);

	return status;
}



int fn_NetSim_DTDMA_add_PropagationInfo_Plot_data(PPROPAGATION_INFO pinfo, double fadingloss)
{

	//PPROPAGATION_INFO pinfo;
	//TOTALLOSS
	double TotalLoss = pinfo->recvPower->dPathloss_db + pinfo->recvPower->dShadowLoss_db + fadingloss;

	ptrplotINFO**** info = parameter_plot_info;
	ptrplotINFO info1 = info[pinfo->nTxId][pinfo->nTxInterface][pinfo->nRxId][pinfo->nRxInterface];

	if (info1->isTotalLossPlotEnable)
		add_plot_data_formatted(info1->netsimTotalLossPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime, -(TotalLoss));

	//PATHLOSS
	if (info1->isPathLossPlotEnable)
		add_plot_data_formatted(info1->netsimPathLossPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime,-( pinfo->recvPower->dPathloss_db));
	//SHADOWLOSS
	if (info1->isShadowLossPlotEnable)
		add_plot_data_formatted(info1->netsimShadowLossPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime, pinfo->recvPower->dShadowLoss_db);

	//FADINGLOSS
	if (info1->isFadingLossPlotEnable)
		add_plot_data_formatted(info1->netsimFadingLossPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime, fadingloss);
	return 1;

}
int fn_NetSim_DTDMA_add_Power_Plot_data(PPROPAGATION_INFO pinfo,double snr,double ber)
{

	//RX_POWER
	ptrplotINFO**** info = parameter_plot_info;
	ptrplotINFO info1 = info[pinfo->nTxId][pinfo->nTxInterface][pinfo->nRxId][pinfo->nRxInterface];

	if (info1->isrxPowerPlotEnable)
		add_plot_data_formatted(info1->netsimrxPowerPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime, pinfo->recvPower->dRxPower_dbm);

	if (info1->isBERPlotEnable)
		add_plot_data_formatted(info1->netsimBERPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime,ber);

	if (info1->isSNRPlotEnable)
		add_plot_data_formatted(info1->netsimSNRPlotVar, "%lf,%lf",
			pstruEventDetails->dEventTime, snr);

	return 1;
}
