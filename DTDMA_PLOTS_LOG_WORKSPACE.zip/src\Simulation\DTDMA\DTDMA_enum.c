#include "main.h"
#include "DTDMA_enum.h"
#undef _NETSIM_DTDMA_ENUM_H_
#define GENERATE_ENUM_STRINGS
#include "DTDMA_enum.h"
#undef GENERATE_ENUM_STRINGS
