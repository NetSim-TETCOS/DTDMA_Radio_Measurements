#include "main.h"
#include "OSPF.h"
#include "OSPF_enum.h"
#undef _NETSIM_OSPF_ENUM_H_
#define GENERATE_ENUM_STRINGS
#include "OSPF_enum.h"
#undef GENERATE_ENUM_STRINGS
