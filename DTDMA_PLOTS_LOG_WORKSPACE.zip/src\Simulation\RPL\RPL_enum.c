#include "main.h"
#include "RPL.h"
#include "RPL_Enum.h"
#undef _NETSIM_RPL_ENUM_H_
#define GENERATE_ENUM_STRINGS
#include "RPL_Enum.h"
#undef GENERATE_ENUM_STRINGS
