#include "main.h"
#include "TDMA_enum.h"
#undef _NETSIM_TDMA_ENUM_H_
#define GENERATE_ENUM_STRINGS
#include "TDMA_enum.h"
#undef GENERATE_ENUM_STRINGS
