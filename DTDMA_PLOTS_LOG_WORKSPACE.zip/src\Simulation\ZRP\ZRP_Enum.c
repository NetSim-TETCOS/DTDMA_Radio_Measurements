#include "main.h"
#include "ZRP.h"
#include "ZRP_Enum.h"
#undef _NETSIM_ZRP_ENUM_H_
#define GENERATE_ENUM_STRINGS
#include "ZRP_Enum.h"
#undef GENERATE_ENUM_STRINGS

